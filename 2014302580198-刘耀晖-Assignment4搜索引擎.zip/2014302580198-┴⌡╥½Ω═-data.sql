-- MySQL dump 10.13  Distrib 5.7.9, for Win32 (AMD64)
--
-- Host: localhost    Database: heavy's
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `2014302580198_professor_info`
--

DROP TABLE IF EXISTS `2014302580198_professor_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `2014302580198_professor_info` (
  `name` varchar(45) COLLATE utf8_bin NOT NULL,
  `educationBackground` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `researchInterests` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `2014302580198_professor_info`
--

LOCK TABLES `2014302580198_professor_info` WRITE;
/*!40000 ALTER TABLE `2014302580198_professor_info` DISABLE KEYS */;
INSERT INTO `2014302580198_professor_info` VALUES ('Bob Kinicki',' Math BS, CWRU, 1968 Computer Science MS, Indiana University, 1975 Computer Science Ph.D. Duke University 1978 ','\nSensor networks\nWireless networks\nNetwork performance\nComputer medical applications\n','rek@wpi.edu','+1-508-831-6116'),('Candace L. Sidner',' B.A. Math, Kalamazoo College 1971 M.S. Computer Science, Univ of Pittsburgh, 1975 Ph.D. Computer Science, MIT, 1979 ','\nNatural Language Processing\nAI\nIntelligent User Interfaces\nCollaboration\nHuman Robot Interaction\n','sidner@wpi.edu','+1-508-831-6637'),('Carolina Ruiz',' BS, Computer Science, Universidad de Los Andes, 1988 BS, Mathematics, Universidad de Los Andes, 1989 MS, Computer Science, Universidad de Los Andes, 1990 Ph.D., Computer Science, University of Maryland College Park, 1996 ','\nData Mining\nMachine Learning\nArtificial Intelligence\nGenomics\nClinical Medicine\n','ruiz@wpi.edu','+1-508-831-5640'),('Charles Rich',' B.A.Sc., University of Toronto, 1973 S.M., Massachusetts Institute of Technology, 1975 Ph.D., Massachusetts Institute of Technology, 1980 ','\nArtificial intelligence\nHuman-robot interaction\nIntelligent user interfaces\nSerious games\n','rich@wpi.edu','+1-508-831-5945'),('Craig A. Shue',' BS, Ohio University, 2004 MS, Indiana University, 2006 PhD, Indiana University, 2009 ','\nCyber Security\nComputer Networking\nDistributed Systems\n','cshue@wpi.edu','+1-508-831-4933'),('Craig Wills',' BS, University of Nebraska, 1982 MS, Purdue University, 1984 PhD, Purdue University, 1988 ','\nInternet Measurement\nOnline Privacy\nDistributed Computing\nUser Interfaces\n','cew@wpi.edu','+1-508-831-5622'),('Daniel J. Dougherty',' BS University of Maryland 1974 PhD University of Maryland 1982 ','\nLogic\nSecurity\nSoftware\n','dd@wpi.edu','+1-508-831-5621'),('David C. Brown',' B.Sc. (Honors), 1st Class, Computer Science, North Staffordshire Polytechnic, 1970. M.Sc., Computing, University of Kent, 1975. M.S., Computer & Information Science, The Ohio State University,1977. Ph.D., Computer & Information Science, The Ohio State University, 1984. ','\nAI in Design\nHuman Computer Interaction\nArtificial Intelligence\nIntelligent Interfaces\n','dcb@wpi.edu','+1-508-831-5618'),('David Finkel',' B.A., Temple University, 1966 M.S., University of Chicago, 1967 PhD., University of Chicago, 1971 ','\nComputer System Performacne Evaluation\nVideo Game User Experience\n','dfinkel@wpi.edu','+1-508-831-5416'),('Dmitry Berenson',' BS, Cornell University, 2005 MS, Carnegie Mellon University, 2009 PhD, Carnegie Mellon University, 2011 ','\nMotion planning\nRobotic manipulation\nMedical robotics\n','dberenson@wpi.edu','+1-508-831-5587'),('Elke Angelika Rundensteiner',' BS (Vordiplom), J.W. Goethe University, Frankfurt, Germany. Master of Science Minor, Business, J.W.Goethe Univ. Frankfurt, Germany. MS, Computer Science, Florida State University, Tallahassee, Florida. Phd., Computer Science, University of California, Irvine, California. ','\nDatabase Systems\nData Streaming\nBig Data\nMonitoring and Tracking Applications\nData Mining\n','rundenst@wpi.edu','+1-508-831-5815'),('Emmanuel O. Agu',' B. Eng, University of Benin, Nigeria M.S.E.C.E, University of Massachusetts, Amherst PhD, University of Massachusetts, Amherst ','\nMobile Computing\nUbiquitous Computing\nWireless Networking\nComputer Graphics\nMobile Graphics\n','emmanuel@wpi.edu','+1-508-831-5568'),('Gary F. Pollice',' BS, Rutgers, 1973 MS, U. Massachusetts, Lowell 1994 ','\nSoftware Engineering\nLanguages and implementations\n','gpollice@wpi.edu','+1-508-831-6793'),('George T. Heineman',' BS, Dartmouth College, 1985 MS, Columbia University, 1990 PhD, Columbia University, 1996 ','\nSoftware Engineering\nComponent-Based Software Engineering\nSoftware Architecture\nModularity and Composition\n','heineman@wpi.edu','+1-508-831-5502'),('Joseph Beck','  Research Interests  Educational data mining Education  BS, Carnegie Mellon University PhD, University of Massachusetts, Amherst ','\nEducational data mining\n','josephbeck@wpi.edu','+1-508-831-6156'),('Joshua D. Guttman',' A.B., Princeton University, 1975 M.A., University of Chicago, 1976 Ph.D., University of Chicago, 1984 ','\nInformation Security\nTheoretical Computer Science\nLogic\nFormal Methods\nProgramming Languages\n','guttman@wpi.edu','+1-508-831-6054'),('Kathi Fisler','Human-centered security ','\nComputing Education\nHuman-centered security\nFormal methods\n','kfisler@wpi.edu','+1-508-831-5118'),('Krishna Kumar Venkatasubramanian',' BS, Webster University, 2001 MS, Arizona State University, 2004 PhD, Arizona State University, 2009 Postdoc (2009-2012) University of Pennsylvania ','\nMedical Cyber-Physical SystemsSecurity and Trust\nSecurity for Next-Gen Wearable Systems\nTrust and Reputation Management\nPervasive/Ubiquitous Computing\nDistributed Systems\n','kven@wpi.edu','+1-508-831-6571'),('Mark Claypool',' BA, Mathematics, Colorado College MS, Computer Science, University of Minnesota PhD, Computer Science, University of Minnesota ','\nMultimedia Networking\nCongestion Control\nNetwork Games\n','claypool@wpi.edu','+1-508-831-5409'),('Micha Hofri',' BS -- IIT, Physics MS -- IIT, Physics D.Sc. --IIT, Industrial engineering ','\nAnalysis of algorithms\nMathematical tools of analysis\nTypesetting\nOptimization\nSimulation\n','hofri@wpi.edu','+1-508-831-6911'),('Michael A. Gennert',' BS, CS, Massachusetts Institute of Technology, 1980 BS, EE, Massachusetts Institute of Technology, 1980 MS, EECS, Massachusetts Institute of Technology, 1980 PhD, EECS, Massachusetts Institute of Technology, 1987 ','\nRobotics\nMedical Imaging\nAutionomous Navigation\n','michaelg@wpi.edu','+1-508-831-5476'),('Mohamed Eltabakh',' B.S. in Computer Science, Faculty of Engineering, Alexandria University, Egypt, May 1999 M.S. in Computer Science, Faculty of Engineering, Alexandria University, Egypt, May 2001 M.S. in Computer Science, Purdue University, West Lafayette, IN, Summer 2005 Ph.D. in Computer Science, Purdue University, West Lafayette, IN, May 2010 ','\nDatabase Systems\nLarge-Scale Analytics\nScientific Data Management\nQuery Processing and Indexing\nCloud Computing\n','meltabakh@wpi.edu','+1-508-831-6421'),('Neil T. Heffernan',' B.A., Amherst College, 1993 M.S., Carnegie Mellon University, 1998 Ph.D., Carnegie Mellon University, 2001 ','','nth@wpi.edu','+1-508-831-5569'),('Robert W. Lindeman',' BA, Brandeis University, 1987 MS, University of Southern California, 1992 ScD, The George Washington University, 1999 ','\nVirtual Reality\nComputer Graphics\nHuman-Computer Interaction\nAdvanced Game Interfaces\n','gogo@wpi.edu','+1-508-831-6712'),('Sonia Chernova',' BS, Carnegie Mellon University, 2003 PhD, Carnegie Mellon University, 2009 ','\nautonomous robots\ninteractive robot learning\nhuman computation\ncrowdsourcing\nmachine learning\n','soniac@wpi.edu','+1-508-831-6547'),('Stanley M. Selkow',' B.S., Carnegie Institute of Technology, 1965 M.S., University of Pennsylvania , 1967 Ph.D., University of Pennsylvania , 1970 ','\nGraph Theory and Combinatorics\nDesign and Analysis of Algorithms\n','sms@wpi.edu','+1-508-831-5449');
/*!40000 ALTER TABLE `2014302580198_professor_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-18 15:44:06
